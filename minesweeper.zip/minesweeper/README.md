# Build process
delete cmakecache.txt
```bash
cmake -B build
cmake --build build
./bin/minesweeper
```